import os

index = 100
while index < 200:
    os.system('wget https://dash.akamaized.net/akamai/bbb_30fps/bbb_a64k/bbb_a64k_' +
          str(index) + '.m4a')
    index += 1
